import '../styles/h5p-multi-media-choice.scss';
import MultiMediaChoice from '../scripts/h5p-multi-media-choice.js';

// Load library
H5P = H5P || {};
H5P.MultiMediaChoice = MultiMediaChoice;
