require('../scripts/config');
// Load library
H5P = H5P || {};
H5P.MathDisplay = require('../scripts/mathdisplay').default;
