Please check out existing repo issues, and the issues in this document.
Create new issues in the repository if it doesn't exist or collaborate with
others if it already exists.
Create a pull request with test coverage for the issue :)
