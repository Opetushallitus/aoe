// Load library
H5P.SimpleMultiChoice = require('../scripts/simple-multiple-choice').default;
