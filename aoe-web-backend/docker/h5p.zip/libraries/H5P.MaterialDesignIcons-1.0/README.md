H5P Material Design Icons
==========

Used in H5P libraries to provide icons. 

## License

Material Design Icons are licensed under the Apache License Version 2.0. See [the material design icons documentation](http://google.github.io/material-design-icons/#icon-font-for-the-web) for more information.