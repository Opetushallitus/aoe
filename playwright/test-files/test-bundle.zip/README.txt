Tama zip ei sisalla index.html-tiedostoa, joten sita ei voi esikatsella.
